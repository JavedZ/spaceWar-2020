The Sun

A texture of the sun for use in sky modeling


Author is Mystic Mike (Mike Hosker)

licences:
	GPL v2 (or at your option any later version)
	CC-BY-SA 3.0 (or at your option any later version)


